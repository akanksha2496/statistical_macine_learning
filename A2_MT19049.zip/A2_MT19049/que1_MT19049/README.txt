every code here is of que 1 and there parts a,b,c,d,e,f,g,h,i.
are in .py file