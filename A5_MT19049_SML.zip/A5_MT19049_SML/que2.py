import numpy as np
from matplotlib import pyplot as plt

from sklearn.gaussian_process import GaussianProcessRegressor
from sklearn.gaussian_process.kernels import RBF, ConstantKernel as C,WhiteKernel,ExpSineSquared,RationalQuadratic
from sklearn.linear_model import LinearRegression

X = np.atleast_2d([0.,2.,4.,6.,8.,10.,11.]).T

y = np.atleast_2d([-45,-58,-36,-59,-36,-55,-64]).T

x = np.atleast_2d([1.,3.,5.,7.,9.]).T

# https://scikit-learn.org/stable/modules/gaussian_process.html
# kernel =RBF(length_scale=1,length_scale_bounds=[1e-2, 1e3]) 
# https://scikit-learn.org/stable/modules/gaussian_process.html


k = 50.0**2 * RBF(length_scale=50.0)+2.0*2 * RBF(length_scale=90.0)* ExpSineSquared(length_scale=1.0) +0.1*2 * RBF(length_scale=0.1)+ WhiteKernel(noise_level=0.1*2,noise_level_bounds=(1e-3, 1e100))  

gp = GaussianProcessRegressor(kernel=k, n_restarts_optimizer=10,alpha=0.01)

gp.fit(X, y)
y_pred, sigma = gp.predict(x, return_std=True)
print("Value at Test points",y_pred)
print("variance:",(sigma)**2)
print("sigma:",sigma)

import matplotlib.pyplot as plt 
# refrences:https://www.geeksforgeeks.org/graph-plotting-in-python-set-1/
# line 1 points 
x1 = x
y1 = [-51,-63,-52,-62,-43] 

plt.plot(x, y1, label = "actual") 


y2 =y_pred
# plotting the line 2 points 
plt.plot(x, y2, label = "predicted") 

# naming the x axis 
plt.xlabel('distance') 
# naming the y axis 
plt.ylabel('singnal strength') 

plt.legend() 

plt.show()

import pandas as pd
data1=[[1,-51],[3,-63],[5,-52],[7,-62],[9,-43]]
Test = pd.DataFrame(data1, columns = ['Distance', 'Strength']) 


# Plot the function, the prediction and the 95% confidence interval based on
# the MSE
plt.figure()
plt.plot(x, Test["Strength"], label="True value")
#plt.plot(X, y, 'r.', markersize=10, label='Observations')
plt.plot(x, y_pred, 'b-', label='Prediction')
plt.fill(np.concatenate([x, x[::-1]]),np.concatenate([y_pred - 1.9600 * sigma,(y_pred + 1.9600 * sigma)[::-1]]), alpha=.5, fc='b', ec='None', label='95% confidence interval')

plt.xlabel('strenghth')
plt.ylabel('distance')

plt.legend(loc='upper left')

plt.show()







