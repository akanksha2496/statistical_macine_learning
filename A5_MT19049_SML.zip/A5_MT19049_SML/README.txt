que1:
name mention for all algorithm applied.
run each files after giving path of its train data file in mentioned,where i have given my drive address.
que2:
run it directly without load anything.